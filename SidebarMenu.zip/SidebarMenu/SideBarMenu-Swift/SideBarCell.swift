//
//  SideBarCell.swift
//  SideBarMenu-Swift
//
//  Created by Wim on 8/6/16.
//  Copyright © 2016 Kwikku. All rights reserved.
//

import Foundation

class SideBarCell: UITableViewCell {
    
    @IBOutlet weak var icon: UIImageView!
    @IBOutlet weak var title: UILabel!
    
}