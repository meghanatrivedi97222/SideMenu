//
//  HomeViewController.swift
//  SideBarMenu-Swift
//
//  Created by Wim on 8/6/16.
//  Copyright © 2016 Kwikku. All rights reserved.
//

import Foundation

class HomeViewController: UIViewController {
    
    @IBOutlet weak var menuBar: UIBarButtonItem!
    var isVertical : Bool = false
    override func viewDidLoad() {
        setMenuBarBtn(menuBar: menuBar)
        self.revealViewController().rearViewRevealWidth = self.view.frame.width - 100
    }
    func setMenuBarBtn(menuBar: UIBarButtonItem) {
        menuBar.target = revealViewController()
        menuBar.action = #selector(SWRevealViewController.revealToggle(_:))
        view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
    }
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask
    {
        return UIInterfaceOrientationMask.portrait
    }
}
