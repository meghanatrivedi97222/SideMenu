# SidebarMenu-Swift

Sidebar Menu Navigation with SWRevealViewController

![alt tag](https://3.bp.blogspot.com/-lBGw4vqSpH8/V6YuyJHSwEI/AAAAAAAACBU/IApHG0zKhIMpmvjD6LjQMV8GAsNZuKIUQCLcB/s400/Simulator%2BScreen%2BShot%2BAug%2B6%252C%2B2016%252C%2B8.36.56%2BPM.png "Sidebar Menu")

# Libraries

* [SWRevealViewController](https://github.com/John-Lluch/SWRevealViewController)
